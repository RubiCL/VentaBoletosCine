package vboletos;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

public class Menu extends javax.swing.JFrame {
    
    public Menu() {
        initComponents();
        super.setTitle("Cine Lumiere");
        super.setResizable(false);
        super.setLocationRelativeTo(null);
    }
    
    void limpiarCantidad(){
        txtCantBoletosAdulto.setText("");
        txtCantBoletosNino.setText("");        
    }
    
    void calculo() {
        
        double cantidadAdultos = 0.0, cantidadNinos = 0.0;
        double precioAdultos = 0.0, precioNinos = 0.0;
        double TotalAdultos = 0, TotalNinos = 0, Total;

        if ("".equals(txtCantBoletosNino.getText())) {
            String ninguno = "0.0";
            Datos.lblTotalBolNinos.setText(ninguno);
            Datos.txtCantBoletosAdultos.setText("0");
        } else {
            cantidadNinos = Double.parseDouble(txtCantBoletosNino.getText());
            precioNinos = Double.parseDouble(lblPBoletoNino.getText());
            TotalNinos = (cantidadNinos * precioNinos);
            Datos.lblTotalBolNinos.setText(TotalNinos + "");
        }
        
        if("".equals(txtCantBoletosAdulto.getText())){
            txtCantBoletosAdulto.setText("");
        }else{
            cantidadAdultos = Double.parseDouble(txtCantBoletosAdulto.getText());
            precioAdultos = Double.parseDouble(lblPBoletoAdulto.getText());
            TotalAdultos = (cantidadAdultos * precioAdultos);
            Datos.lblTotalBolAdultos.setText(TotalAdultos + "");
        }
        
        Total = TotalNinos + TotalAdultos;
        Datos.lblTotalPago.setText(Total + "");
    }
    
    void pasaDatos() {
        Datos.txtCantBoletosAdultos.setText(txtCantBoletosAdulto.getText());
        Datos.txtCantBoletosNinos.setText(txtCantBoletosNino.getText());
    }
      
    void tarjeta(){
        if (rdbtnTarjeta.isSelected()) {
            Datos.txtEfectRecibido.setText("Paga con tarjeta");
            Datos.txtEfectRecibido.setEditable(false);
            Datos.jButton1.setVisible(false);
            Datos.btnComprar.setEnabled(true);           
        }
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup2 = new javax.swing.ButtonGroup();
        jPanel1 = new javax.swing.JPanel();
        lblBoletos = new javax.swing.JLabel();
        lblNino = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        lblAdulto = new javax.swing.JLabel();
        lblPBoletoNino = new javax.swing.JLabel();
        lblPBoletoAdulto = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        lblCantidad = new javax.swing.JLabel();
        txtCantBoletosAdulto = new javax.swing.JTextField();
        txtCantBoletosNino = new javax.swing.JTextField();
        lblFormPago = new javax.swing.JLabel();
        rdbtnEfectivo = new javax.swing.JRadioButton();
        rdbtnTarjeta = new javax.swing.JRadioButton();
        btnContinuar = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        jlbl3D = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(204, 204, 255));

        lblBoletos.setFont(new java.awt.Font("Comic Sans MS", 1, 25)); // NOI18N
        lblBoletos.setText("BOLETOS");

        lblNino.setFont(new java.awt.Font("Comic Sans MS", 1, 15)); // NOI18N
        lblNino.setText("Niño");

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel1.setText("Precio Boleto");

        lblAdulto.setFont(new java.awt.Font("Comic Sans MS", 1, 15)); // NOI18N
        lblAdulto.setText("Adulto");

        lblPBoletoNino.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        lblPBoletoNino.setText("35");

        lblPBoletoAdulto.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        lblPBoletoAdulto.setText("60");

        jLabel2.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        jLabel2.setText("$");

        lblCantidad.setFont(new java.awt.Font("Comic Sans MS", 0, 15)); // NOI18N
        lblCantidad.setText("Cantidad");

        txtCantBoletosAdulto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCantBoletosAdultoActionPerformed(evt);
            }
        });

        lblFormPago.setFont(new java.awt.Font("Comic Sans MS", 1, 18)); // NOI18N
        lblFormPago.setText("FORMA DE PAGO");

        rdbtnEfectivo.setBackground(new java.awt.Color(153, 153, 255));
        rdbtnEfectivo.setFont(new java.awt.Font("Comic Sans MS", 1, 14)); // NOI18N
        rdbtnEfectivo.setText("Pago en Efectivo");

        rdbtnTarjeta.setBackground(new java.awt.Color(153, 153, 255));
        rdbtnTarjeta.setFont(new java.awt.Font("Comic Sans MS", 1, 14)); // NOI18N
        rdbtnTarjeta.setText("Pago en Tarjeta");

        btnContinuar.setBackground(new java.awt.Color(102, 102, 102));
        btnContinuar.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btnContinuar.setText("Continuar");
        btnContinuar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnContinuarActionPerformed(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Comic Sans MS", 0, 12)); // NOI18N
        jLabel3.setText("$");

        jlbl3D.setFont(new java.awt.Font("Comic Sans MS", 1, 14)); // NOI18N
        jlbl3D.setText("3D");

        jLabel4.setFont(new java.awt.Font("Comic Sans MS", 1, 14)); // NOI18N
        jLabel4.setText("Boletos");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(44, 44, 44)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(127, 127, 127)
                                .addComponent(lblFormPago, javax.swing.GroupLayout.PREFERRED_SIZE, 181, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jLabel1)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(lblCantidad)
                                .addGap(98, 98, 98)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(lblAdulto)
                                    .addComponent(lblBoletos)))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(112, 112, 112)
                        .addComponent(jlbl3D)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 8, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(110, 110, 110)
                                .addComponent(lblPBoletoAdulto)
                                .addGap(79, 79, 79)
                                .addComponent(jLabel3)
                                .addGap(18, 18, 18)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGap(10, 10, 10)
                                        .addComponent(lblPBoletoNino))
                                    .addComponent(lblNino)))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(77, 77, 77)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(txtCantBoletosAdulto, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(txtCantBoletosNino, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(jLabel2))))))
                .addContainerGap(127, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(61, 61, 61)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(rdbtnTarjeta)
                    .addComponent(rdbtnEfectivo))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnContinuar)
                .addGap(60, 60, 60))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel4)
                .addGap(200, 200, 200))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblBoletos)
                .addGap(26, 26, 26)
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblNino)
                    .addComponent(lblAdulto))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblPBoletoAdulto)
                    .addComponent(lblPBoletoNino)
                    .addComponent(jLabel2)
                    .addComponent(jLabel3)
                    .addComponent(jlbl3D))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel4)
                .addGap(12, 12, 12)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblCantidad)
                    .addComponent(txtCantBoletosAdulto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtCantBoletosNino, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(10, 10, 10)
                .addComponent(lblFormPago)
                .addGap(33, 33, 33)
                .addComponent(rdbtnEfectivo)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 18, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(rdbtnTarjeta)
                    .addComponent(btnContinuar))
                .addGap(21, 21, 21))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnContinuarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnContinuarActionPerformed
        buttonGroup2.add(rdbtnEfectivo);
        buttonGroup2.add(rdbtnTarjeta);
        if(txtCantBoletosAdulto.getText().length() == 0 ){
            JOptionPane.showMessageDialog(this, "Faltan datos por completar", "ERROR", JOptionPane.INFORMATION_MESSAGE);
        }else{
           Datos obj = new Datos();
            pasaDatos();
            tarjeta();
            calculo();
            obj.setVisible(true); 
        }
    }//GEN-LAST:event_btnContinuarActionPerformed

    private void txtCantBoletosAdultoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCantBoletosAdultoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCantBoletosAdultoActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Menu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Menu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Menu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Menu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Menu().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnContinuar;
    public static javax.swing.ButtonGroup buttonGroup2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    public static javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel jlbl3D;
    private javax.swing.JLabel lblAdulto;
    private javax.swing.JLabel lblBoletos;
    private javax.swing.JLabel lblCantidad;
    private javax.swing.JLabel lblFormPago;
    private javax.swing.JLabel lblNino;
    private javax.swing.JLabel lblPBoletoAdulto;
    private javax.swing.JLabel lblPBoletoNino;
    private javax.swing.JRadioButton rdbtnEfectivo;
    private javax.swing.JRadioButton rdbtnTarjeta;
    public static javax.swing.JTextField txtCantBoletosAdulto;
    public static javax.swing.JTextField txtCantBoletosNino;
    // End of variables declaration//GEN-END:variables
}