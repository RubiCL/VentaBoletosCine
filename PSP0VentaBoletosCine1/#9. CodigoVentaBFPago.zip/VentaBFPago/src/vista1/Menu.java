package vista1;

import javax.swing.JLabel;
//import vista1.Datos;

/**
 *
 * @author LUIS ALBERTO
 */
public class Menu extends javax.swing.JFrame {
    
    /**
     * Creates new form Menu
     */
    public Menu() {
        initComponents();
        super.setTitle("Cine Lumiere");
        super.setResizable(false);
        super.setLocationRelativeTo(null);
    }

    void calculo() {
        
        double cantidadBoletos = 0.0;
        double precioBoletos = 0.0;
        double TotalB = 0, Total;

        if ("".equals(txtCantidadBoletos.getText())) {
            String ninguno = "0.0";
            Datos.lblTotalBoletos.setText(ninguno);
            Datos.txtCantidadBoletos.setText("0");
        } else {
            cantidadBoletos = Double.parseDouble(txtCantidadBoletos.getText());
            precioBoletos = Double.parseDouble(lblPrecioBoleto.getText());
            TotalB = (cantidadBoletos * precioBoletos);
            Datos.lblTotalBoletos.setText(TotalB + "");
        }

        Total = TotalB + TotalB;
        Datos.lblTotalPago.setText(Total + "");

    }
    
    void pasaDatos() {
        Datos.txtCantidadBoletos.setText(txtCantidadBoletos.getText());
    }

    
     void tarjeta(){
        if (rdbtnTarjeta.isSelected()) {
            Datos.txtEfectRecibido.setText("Paga con tarjeta");
            Datos.txtEfectRecibido.setEditable(false);
            Datos.btnComprar.setEnabled(true);
        }
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lblFormPago = new javax.swing.JLabel();
        rdbtnEfectivo = new javax.swing.JRadioButton();
        rdbtnTarjeta = new javax.swing.JRadioButton();
        btnContinuar = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        lblPrecioBoleto = new javax.swing.JLabel();
        lblCantidad = new javax.swing.JLabel();
        txtCantidadBoletos = new javax.swing.JTextField();
        lblBoletos = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        lblFormPago.setFont(new java.awt.Font("Comic Sans MS", 1, 18)); // NOI18N
        lblFormPago.setText("FORMA DE PAGO");

        rdbtnEfectivo.setFont(new java.awt.Font("Comic Sans MS", 1, 14)); // NOI18N
        rdbtnEfectivo.setText("Pago en Efectivo");

        rdbtnTarjeta.setFont(new java.awt.Font("Comic Sans MS", 1, 14)); // NOI18N
        rdbtnTarjeta.setText("Pago en Tarjeta");

        btnContinuar.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btnContinuar.setText("Continuar");
        btnContinuar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnContinuarActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Tahoma", 2, 12)); // NOI18N
        jLabel1.setText("Precio Boleto:");

        jLabel2.setText("$");

        lblPrecioBoleto.setText("50");

        lblCantidad.setText("Cantidad");

        txtCantidadBoletos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCantidadBoletosActionPerformed(evt);
            }
        });

        lblBoletos.setText("Boletos");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(btnContinuar))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(33, 33, 33)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(rdbtnTarjeta)
                            .addComponent(rdbtnEfectivo))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(43, 43, 43)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(lblFormPago, javax.swing.GroupLayout.PREFERRED_SIZE, 181, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(63, 63, 63)
                                .addComponent(lblBoletos))
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(lblCantidad)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(txtCantidadBoletos, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(18, 18, 18)
                                    .addComponent(jLabel2))))
                        .addGap(18, 18, 18)
                        .addComponent(lblPrecioBoleto)))
                .addGap(49, 49, 49))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(31, 31, 31)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblFormPago)
                    .addComponent(lblBoletos))
                .addGap(28, 28, 28)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(jLabel2)
                    .addComponent(lblPrecioBoleto))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblCantidad)
                    .addComponent(txtCantidadBoletos, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 13, Short.MAX_VALUE)
                .addComponent(rdbtnEfectivo)
                .addGap(18, 18, 18)
                .addComponent(rdbtnTarjeta)
                .addGap(18, 18, 18)
                .addComponent(btnContinuar)
                .addGap(30, 30, 30))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnContinuarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnContinuarActionPerformed
        Datos obj = new Datos();
            pasaDatos();
            tarjeta();
            calculo();
            obj.setVisible(true);
    }//GEN-LAST:event_btnContinuarActionPerformed

    private void txtCantidadBoletosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCantidadBoletosActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCantidadBoletosActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Menu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Menu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Menu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Menu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Menu().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnContinuar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel lblBoletos;
    private javax.swing.JLabel lblCantidad;
    private javax.swing.JLabel lblFormPago;
    private javax.swing.JLabel lblPrecioBoleto;
    private javax.swing.JRadioButton rdbtnEfectivo;
    private javax.swing.JRadioButton rdbtnTarjeta;
    private javax.swing.JTextField txtCantidadBoletos;
    // End of variables declaration//GEN-END:variables
}